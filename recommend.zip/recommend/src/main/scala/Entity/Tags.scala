package Entity

case class Tags(userId:Int,movieId:Int,tag:String,timestamp:Int)