package Entity

case class Links (movieId:Int,imdbId:Int,tmdbId:Int)
