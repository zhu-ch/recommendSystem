package Entity

case class Movies(movieId:Int,title:String,genres:String)