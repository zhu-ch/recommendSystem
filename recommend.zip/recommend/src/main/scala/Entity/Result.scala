package Entity

case class Result(userId:Int,movieId:Int,rating:Double)