package DataLoader

import Conf.MyConfig
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel

object SplitData extends MyConfig{
  def main(args: Array[String]): Unit = {
    System.out.println("正在处理")

    // 这里cache内存不够，会报错,要增加内存才行
    spark.catalog.cacheTable("ratings",StorageLevel.MEMORY_AND_DISK)

    System.out.println("取出全部数据")

    // 取第一行.first() first ：返回的是一个Row对象 第一列元素.getLong(0)
    val count = spark.sql("select count(1) from ratings").first().getLong(0)
    val percent = 0.8

    val trainingdatacount = (count * percent).toInt  // 训练数据集大小
    val testdatacount = (count * (1 - percent)).toInt  // 测试数据集大小

    System.out.println("正在进行排序")

    // 1.将数据按时间 升序排序
    val trainingDataAsc = spark.sql(s"select userId,movieId,rating from ratings order by timestamp asc")
    // 2.数据写入到HDFS上
    trainingDataAsc.write.mode(SaveMode.Overwrite).parquet("/tmp/trainingDataAsc")
    // 3.将数据加载到数据仓库中去
    spark.sql("drop table if exists trainingDataAsc")
    spark.sql("create table if not exists trainingDataAsc(userId int,movieId int,rating double) stored as parquet")
    spark.sql("load data inpath '/tmp/trainingDataAsc' overwrite into table trainingDataAsc")

    // 将数据按时间 降序排序
    val trainingDataDesc = spark.sql(s"select userId,movieId,rating from ratings order by timestamp desc")
    trainingDataDesc.write.mode(SaveMode.Overwrite).parquet("/tmp/trainingDataDesc")
    spark.sql("drop table if exists trainingDataDesc")
    spark.sql("create table if not exists trainingDataDesc(userId int,movieId int,rating double) stored as parquet")
    spark.sql("load data inpath '/tmp/trainingDataDesc' overwrite into table trainingDataDesc")


    /**
      * 1.获取80% 升序排列数据进行训练模型
      */
    val trainingData = spark.sql(s"select * from trainingDataAsc limit $trainingdatacount")
    trainingData.write.mode(SaveMode.Overwrite).parquet("/tmp/trainingData")
    spark.sql("drop table if exists trainingData")
    spark.sql("create table if not exists trainingData(userId int,movieId int,rating double) stored as parquet")
    spark.sql("load data inpath '/tmp/trainingData' overwrite into table trainingData")

    /**
      * 2.获取20% 降序排列数据进行测试模型
      */
    val testData = spark.sql(s"select * from trainingDataDesc limit $testdatacount")
    testData.write.mode(SaveMode.Overwrite).parquet("/tmp/testData")
    spark.sql("drop table if exists testData")
    spark.sql("create table if not exists testData(userId int,movieId int,rating double) stored as parquet")
    spark.sql("load data inpath '/tmp/testData' overwrite into table testData")

  }
}
