package DataLoader


import Conf.MyConfig
import Entity._
import org.apache.spark.sql.{SaveMode, SparkSession}

/**
  * @Description 将本地文件处理后存入Hive中
  */

object LoadData extends MyConfig{
  def main(args: Array[String]): Unit = {

    /**
      * 处理links.txt
      */
    import spark.implicits._
    val links = sc.textFile("file:///home/hadoop/data/links.txt",minPartitions) //DRIVER
    .filter(!_.endsWith(",")) //EXRCUTER
      .map(_.split(",")) //EXRCUTER
      .map(x => Links(x(0).trim.toInt, x(1).trim.toInt,x(2).trim.toInt))
      .toDF()

    println("===============links===================:",links.count())
    links.show()

    // 把数据写入到HDFS上
    links.write.mode(SaveMode.Overwrite).parquet("/tmp/links")

    // 将数据从HDFS加载到Hive数据仓库中去
    spark.sql("drop table if exists links")
    spark.sql("create table if not exists links(movieId int,imdbId int,tmdbId int) stored as parquet")
    spark.sql("load data inpath '/tmp/links' overwrite into table links")

    /**
      * 处理moives.txt
      */
    val movies = sc.textFile("file:///home/hadoop/data/movies.txt",minPartitions)
      .filter(!_.endsWith(","))
      .map(_.split(","))
      .map(x => Movies(x(0).trim.toInt, x(1).trim.toString, x(2).trim.toString))
      .toDF()
    println("===============movies===================:",movies.count())
    movies.show()

    // 把数据写入到HDFS上
    movies.write.mode(SaveMode.Overwrite).parquet("/tmp/movies")

    // 将数据从HDFS加载到Hive数据仓库中去
    spark.sql("drop table if exists movies")
    spark.sql("create table if not exists movies(movieId int,title String,genres String) stored as parquet")
    spark.sql("load data inpath '/tmp/movies' overwrite into table movies")

    /**
      * 处理ratings.txt
      */
    val ratings = sc.textFile("file:///home/hadoop/data/ratings.txt",minPartitions)
      .filter(!_.endsWith(","))
      .map(_.split(","))
      .map(x => Ratings(x(0).trim.toInt, x(1).trim.toInt, x(2).trim.toDouble, x(3).trim.toInt))
      .toDF()
    println("===============ratings===================:",ratings.count())

    ratings.show()

    // 把数据写入到HDFS上
    ratings.write.mode(SaveMode.Overwrite).parquet("/tmp/ratings")

    // 将数据从HDFS加载到Hive数据仓库中去
    spark.sql("drop table if exists ratings")
    spark.sql("create table if not exists ratings(userId int,movieId int,rating Double,timestamp int) stored as parquet")
    spark.sql("load data inpath '/tmp/ratings' overwrite into table ratings")

    /**
      * 处理tags.txt
      */
    val tags = sc.textFile("file:///home/hadoop/data/tags.txt",minPartitions)
      .filter(!_.endsWith(","))
      .map(x => rebuild(x))
      .map(_.split(","))
      .map(x => Tags(x(0).trim.toInt, x(1).trim.toInt, x(2).trim.toString, x(3).trim.toInt))
      .toDF()

    tags.show()

    // 把数据写入到HDFS上
    tags.write.mode(SaveMode.Overwrite).parquet("/tmp/tags")

    // 将数据从HDFS加载到Hive数据仓库中去
    spark.sql("drop table if exists tags")
    spark.sql("create table if not exists tags(userId int,movieId int,tag String,timestamp int) stored as parquet")
    spark.sql("load data inpath '/tmp/tags' overwrite into table tags")
  }
  /**
    * 该方法是用于处理不符合规范的数据
    */
  private def rebuild(input:String): String ={
    val a = input.split(",")

    val head = a.take(2).mkString(",")
    val tail = a.takeRight(1).mkString
    val tag = a.drop(2).dropRight(1).mkString.replaceAll("\"","")
    val output = head + "," + tag + "," + tail
    output
  }

}
