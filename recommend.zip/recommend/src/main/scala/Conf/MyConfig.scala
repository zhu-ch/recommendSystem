package Conf

import java.util.Properties

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.hive.HiveContext

/**
  * Description: 封装初始化操作简化代码
  *
  */
trait MyConfig {


  val spark = SparkSession.builder()
    .enableHiveSupport()
    .getOrCreate()


  val sc = spark.sparkContext
  val hc = new HiveContext(sc)
  val shuffleMinPartitions = "8"
  var minPartitions = 8
  spark.sqlContext.setConf("spark.sql.shuffle.partitions",shuffleMinPartitions)


  //jdbc连接
  val jdbcURL = "jdbc:mysql://47.107.33.13:3306/big_data_course?useUnicode=true&characterEncoding=UTF-8&useSSL=false"
//  val alsTable = "big_data_course.alsTab"
//  val recResultTablerecResultTable = "big_data_course.similarTab"
//  val top5Table = "big_data_course.top5Result"

  val recForUserTable="big_data_course.recommend_for_user"
  val recForMoiveTable="big_data_course.recommend_for_movie"
  val top10RatingTable = "big_data_course.top_rating_movies"
  val top10CountTable = "big_data_course.top_count_movies"

  val mysqlusername = "wang"
  val mysqlpassword = "123456"

  val prop = new Properties
  prop.put("driver", "com.mysql.jdbc.Driver")
  prop.put("user", mysqlusername)
  prop.put("password", mysqlpassword)

}
