package Model_ALS





import Conf.MyConfig
import Entity.Result
import org.apache.spark.SparkContext
import org.apache.spark.mllib.recommendation._
import org.apache.spark.sql.{SaveMode, SparkSession}


object RecommendForAllUsers extends MyConfig{
  def main(args: Array[String]): Unit = {
    val users = spark.sql("select distinct(userId) from trainingData order by userId asc")
    // 取得所有的用户ID
    val user = users.rdd.map(_.getInt(0)).toLocalIterator

    // 推荐后存入mysql数据库
    val modelpath = "/tmp/BestModel/0.5320783752229182"
    val model = MatrixFactorizationModel.load(sc, modelpath)

    while (user.hasNext) {
      val rec = model.recommendProducts(user.next(), 5)
      writeRecResultToMysql(rec, spark, sc)
    }


    def writeRecResultToMysql(uid: Array[Rating], spark: SparkSession, sc: SparkContext) {
      val uidString = uid.map(x => x.user.toString() + ","
        + x.product.toString() + "," + x.rating.toString())

      import spark.implicits._
      val uidDFArray = sc.parallelize(uidString)
      val uidDF = uidDFArray.map(_.split(",")).map(x => Result(x(0).trim().toInt, x(1).trim.toInt, x(2).trim().toDouble)).toDF
      // 写入mysql数据库，数据库配置在 AppConf中
      System.out.println("正在写入数据库")
      uidDF.write.mode(SaveMode.Append).jdbc(jdbcURL, recForUserTable, prop)
    }

  }

}

