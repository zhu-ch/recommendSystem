package Model_ALS

import Conf.MyConfig
import org.apache.spark
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel

/**
  * Description: 为某一用户产生推荐结果
  *
  */
object Recommender extends MyConfig{
  def main(args: Array[String]): Unit = {
    System.out.println("开始推荐")

    // 从trainingData中取得的userid 一定存在于模型中。
    val users = spark.sql("select distinct(userId) from trainingData order by userId asc")
    // 取随意一个用户
    val index = 20
    val uid = users.take(index).last.getInt(0)

    val modelpath = "/tmp/BestModel/0.8736884047034406"
    val model = MatrixFactorizationModel.load(sc, modelpath)
    val rec = model.recommendProducts(uid, 5)
    val recmoviesid = rec.map(_.product)

    println("为用户" + uid + "推荐了以下5部电影：")

    for (i <- recmoviesid) {
      val moviename = spark.sql(s"select title from movies where movieId=$i").first().getString(0)
      println(moviename)
    }

  }
}
