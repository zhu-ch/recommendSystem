package Model_ALS

import Conf.MyConfig
import org.apache.spark.mllib.recommendation.{ALS, Rating}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object TrainModel extends  MyConfig{
  def main(args: Array[String]): Unit = {


    // 训练集，总数据集的80%
    val trainingData = spark.sql("select * from trainingData")
    // 测试集，总数据集的20%
    val testData = spark.sql("select * from testData")


    // 训练集，转为Rating格式
    val ratingRDD = trainingData.rdd.map(x => Rating(x.getInt(0), x.getInt(1), x.getDouble(2)))
    val training2 :RDD[(Int,Int)]  = ratingRDD.map{ case Rating(userid, movieid, rating) => (userid, movieid)}

    // 测试集，转为Rating格式
    val testRDD = testData.rdd.map(x => Rating(x.getInt(0), x.getInt(1), x.getDouble(2)))
    val test2 :RDD[((Int,Int),Double)]= testRDD.map {case Rating(userid, movieid, rating) => ((userid, movieid), rating)}

    //循环次数
    var count = 1
    // 隐藏因子数
    val rank = 50
    // 正则化参数
    val lambda = List(0.001, 0.005, 0.01)
    // 迭代次数
    val iteration = List(10, 15, 20)
    var bestRMSE = Double.MaxValue
    var bestIteration = 0
    var bestLambda = 0.0

    ratingRDD.persist()
    training2.persist()
    test2.persist()

    for (l <- lambda; i <- iteration) {

      val model = ALS.train(ratingRDD, rank, i, l)
      val predict = model.predict(training2).map {
        case Rating(userid, movieid, rating) => ((userid, movieid), rating)
      }

      val predictAndFact = predict.join(test2)

      // 计算RMSE(均方根误差)
      val MSE = predictAndFact.map {
        case ((user, product), (r1, r2)) =>
          val err = r1 - r2
          err * err
      }.mean()

      val RMSE = math.sqrt(MSE)

      println(s"正在进行第 $count 次拟合")
      count = count + 1
      // 如果均方根误差较小就将模型存储下来
      if (RMSE < bestRMSE) {
        model.save(sc, s"/tmp/BestModel/$RMSE")
        bestRMSE = RMSE
        bestIteration = i
        bestLambda = l
      }

    }

    println(s"保存最佳模型至 /tmp/BestModel/$bestRMSE")
    println(s"最佳均方根误差（RMSE）为  $bestRMSE")
    println(s"迭代次数为 $bestIteration")
    println(s"Lambda 为 $bestLambda")
  }
}

