package Model_Statistics

import Conf.MyConfig
import org.apache.spark.sql.SaveMode

/**
  * 获取平均评分最高的10个电影
  */
object TopRating extends MyConfig {

  def main(args: Array[String]) {

    System.out.println("正在从hive仓库中进行查询")
    val ratingsData = spark.sql("cache table ratings")

    val pop = spark.sql("select avg(rating) as rating,count(*) as count,movieId from ratings group by movieId having count(*)>5000 order by rating desc").limit(10)
    pop.createOrReplaceTempView("pop10")
    val top10 = spark.sql("select a.movieId,a.title,b.rating from movies a join pop10 b where a.movieId=b.movieId")

    System.out.println("查询成功,正在写入mysql数据库")
    top10.write.mode(SaveMode.Append).jdbc(jdbcURL, top10RatingTable, prop)

  }
}
