package Model_Similar

import Conf.MyConfig
import org.apache.spark.sql.SaveMode

/**
  * 根据ratings生成电影相似度表
  *
  */
object RecommendForItem extends MyConfig{

  def main(args: Array[String]) {

    // 1. 读取样本数据
    val data_path = "file:///home/hadoop/data/ratings.txt"
    val data = sc.textFile(data_path, 8)
    val user = data.map(_.split(",")).map(f => (ItemPref(f(0), f(1), f(2).toDouble))).cache()
    // 2.建立模型
    val similar = new ItemSimilarity()
    val similar_rdd = similar.Similarity(user, "cooccurrence")
    // 3.存储至mysql数据库
    import spark.implicits._
    val similarDF = similar_rdd.filter(x => x.similar >= 0.4).toDF()
    similarDF.write.mode(SaveMode.Append).jdbc(jdbcURL, recForMoiveTable, prop)
  }

}
